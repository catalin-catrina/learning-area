![](./assets/anglexd.png)

# Angle for Adobe XD

## Getting started

1. Open Adobe XD
2. Select Add-ons > Plugins to launch the Plugin Manager. Search for Angle and click Install.
3. Create your design with XD.
4. Have your own mockup ready or download one of our 500 mockups at designcode.io/angle-xd.
5. Select the screen layer of your mockup, then select Plugins > Angle > Apply Mockup. Or, run the shortcut Ctrl ⌃ + A.
