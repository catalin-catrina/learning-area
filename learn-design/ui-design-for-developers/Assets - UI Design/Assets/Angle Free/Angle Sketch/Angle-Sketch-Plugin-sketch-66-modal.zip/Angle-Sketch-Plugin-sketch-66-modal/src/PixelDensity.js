export const PixelDensity = [
    { title: "Auto", selectionLabel: "Auto" },
    { title: "1x", selectionLabel: "1x" },
    { title: "2x", selectionLabel: "2x" },
    { title: "3x", selectionLabel: "3x" },
    { title: "4x", selectionLabel: "4x" },
]
