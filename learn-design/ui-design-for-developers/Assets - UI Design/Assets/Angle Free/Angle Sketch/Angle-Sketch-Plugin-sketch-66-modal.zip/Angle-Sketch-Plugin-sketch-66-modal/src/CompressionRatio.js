export const CompressionRatio = [
    { selectionLabel: "Best", ratio: 1.0 },
    { selectionLabel: "Better", ratio: 0.9 },
    { selectionLabel: "Good", ratio: 0.8 },
    { selectionLabel: "Average", ratio: 0.7 }
]
